import TodoScreen from "./screens/TodoScreen";
import "./App.css"
function App() {
  return (
    <div>
      <TodoScreen/>
    </div>
  );
}

export default App;
