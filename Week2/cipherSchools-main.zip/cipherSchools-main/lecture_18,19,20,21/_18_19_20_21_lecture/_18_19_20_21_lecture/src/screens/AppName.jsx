import React from 'react'

function AppName() {
  return (
    <div>
      <h1 className='ui-heading text-3xl font-bold'>Todo List</h1>
    </div>
  )
}

export default AppName
